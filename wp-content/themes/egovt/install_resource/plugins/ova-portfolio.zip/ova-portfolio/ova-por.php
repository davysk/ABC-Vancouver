<?php
/*
Plugin Name: Ovatheme Portfolio
Plugin URI: https://themeforest.net/user/ovatheme
Description: Portfolio
Author: Ovatheme
Version: 1.0.8
Author URI: https://themeforest.net/user/ovatheme/portfolio
Text Domain: ova-por
Domain Path: /languages/
*/

if ( !defined( 'ABSPATH' ) ) exit();


if (!class_exists('ovapor')) {
	
	class ovapor
	{
		static $_instance = null;

		function __construct()
		{
			$this -> define_constants();
			$this -> includes();
			$this -> supports();
		}

		function define_constants(){
			$this->define( 'OVAPOR_PLUGIN_FILE', __FILE__ );
			$this->define( 'OVAPOR_PLUGIN_URI', plugin_dir_url( __FILE__ ) );
			$this->define( 'OVAPOR_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
			load_plugin_textdomain( 'ova-por', false, basename( dirname( __FILE__ ) ) .'/languages' );
		}

		function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		public static function instance() {
			if ( !empty( self::$_instance ) ) {
				return self::$_instance;
			}
			return self::$_instance = new self();
		}

		function includes() {

			// inc
			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-custom-post-type.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-get-data.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/ova-core-functions.php' );
			
			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-templates-loaders.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-assets.php' );

			require_once( OVAPOR_PLUGIN_PATH.'inc/class-ova-ajax.php' );


			// admin
			require_once( OVAPOR_PLUGIN_PATH.'admin/class-ova-metabox.php' );

			/* Customize */

			// if( current_user_can('customize') ){
			    require_once OVAPOR_PLUGIN_PATH.'/inc/class-customize.php';
			// }

		}


		function supports() {

			/* Make Elementors */
			if ( did_action( 'elementor/loaded' ) ) {
				include OVAPOR_PLUGIN_PATH.'elementor/class-ova-register-elementor.php';
			}

		}

	}
}

function ovapor() {
	return ovapor::instance();
}

$GLOBALS['ovapor'] = ovapor();