<?php 
defined( 'ABSPATH' ) || exit();

if( !class_exists( 'OVAPOR_assets' ) ){
	class OVAPOR_assets{

		public function __construct(){

			add_action( 'wp_enqueue_scripts', array( $this, 'ovapor_enqueue_scripts' ), 10, 0 );

			/* Add JS for Elementor */
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'ova_enqueue_scripts_elementor_por' ) );

		}



		public function ovapor_enqueue_scripts(){

			// Init Css
			wp_enqueue_style( 'ovapor_style', OVAPOR_PLUGIN_URI.'assets/css/frontend/ovapor-style.css' );

			if ( is_singular( 'ova_por' ) || is_post_type_archive( array( 'ova_por' ) ) || is_tax( 'cat_por' ) ){
				//Isotope
				wp_enqueue_script( 'ovapor_isotope', OVAPOR_PLUGIN_URI.'assets/libs/isotope/isotope.pkgd.min.js', array('jquery'), false, true );
				wp_enqueue_script('imagesloaded');
			}

			if ( is_singular( 'ova_por' ) ){
				wp_enqueue_style( 'fancybox', OVAPOR_PLUGIN_URI.'/assets/libs/fancybox-master/dist/jquery.fancybox.min.css', array(), null);
				wp_enqueue_script( 'fancybox', OVAPOR_PLUGIN_URI.'/assets/libs/fancybox-master/dist/jquery.fancybox.min.js', [ 'jquery' ],false,true);
			}

			// Init Js
			wp_enqueue_script( 'ovapor_script', OVAPOR_PLUGIN_URI.'assets/js/frontend/ovapor-script.js' );
			wp_localize_script( 'ovapor_script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));			

		}

		// Add JS for elementor
		public function ova_enqueue_scripts_elementor_por(){
			wp_enqueue_script( 'script-elementor-por', OVAPOR_PLUGIN_URI. 'assets/js/script-elementor.js', [ 'jquery' ], false, true );
		}


	}
	new OVAPOR_assets();
}
