<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();
$type = isset( $_GET['archive_type_portfolio'] ) ? sanitize_text_field( $_GET['archive_type_portfolio'] ) : '';

$type = $type != '' ? $type : get_theme_mod( 'ova_por_archive_type', 'classic' );

if( $type == 'classic' ){
	ovapor_get_template( 'archive-por-classic.php' );
}else if( $type == 'modern' ) {
	ovapor_get_template( 'archive-por-modern.php' );
} else if( $type == 'grid' ) {
	ovapor_get_template( 'archive-por-grid.php' );
}

get_footer();