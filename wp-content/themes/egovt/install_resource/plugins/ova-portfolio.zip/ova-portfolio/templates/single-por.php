<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();
$type = isset( $_GET['single_type_portfolio'] ) ? sanitize_text_field( $_GET['single_type_portfolio'] ) : '';

$type = $type != '' ? $type : get_theme_mod( 'ova_por_single_type', 'type1' );

if( $type == 'type1' ){
	ovapor_get_template( 'single-por-type1.php' );
}else if( $type == 'type2' ) {
	ovapor_get_template( 'single-por-type2.php' );
} else if( $type == 'type3' ) {
	ovapor_get_template( 'single-por-type3.php' );
}

?>


<?php get_footer( );
