<?php if ( !defined( 'ABSPATH' ) ) exit();

$category = $args['category'];
$post_per_page = $args['total_count'];

$data_options['items']              = $args['item_number'];
$data_options['slideBy']            = $args['slides_to_scroll'];
$data_options['margin']             = $args['margin_items'];
$data_options['autoplayHoverPause'] = $args['pause_on_hover'] === 'yes' ? true : false;
$data_options['loop']               = $args['infinite'] === 'yes' ? true : false;
$data_options['autoplay']           = $args['autoplay'] === 'yes' ? true : false;
$data_options['autoplayTimeout']    = $args['autoplay_speed'];
$data_options['smartSpeed']         = $args['smartspeed'];
$data_options['dots']               = $args['dot_control'] === 'yes' ? true : false;

if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'ova_por',
		'post_status' => 'publish',
		'posts_per_page' => $post_per_page,
	);
} else {
	$args_new= array(
		'post_type' => 'ova_por',
		'post_status' => 'publish',
		'posts_per_page' => $post_per_page,
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_por',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_por_order = [];
if( $args['orderby_post'] === 'ova_por_met_order_por' ) {
	$args_por_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_por_order = [
		'orderby'        => $args['orderby_post'],
	];
}

$args_por = array_merge( $args_new, $args_por_order );

$pors  = new \WP_Query($args_por);

?>
<div class="ova_por_slide por_element">
	<div class="slide-portfolio owl-carousel owl-theme " data-options="<?php echo esc_attr(json_encode($data_options)) ?>">
		<?php
		if( $pors->have_posts() ){ 
			while( $pors->have_posts() ){
				$pors->the_post();
				$id = get_the_ID();
				$title = get_the_title();

				$url_img = get_the_post_thumbnail_url( $id, 'egovt_portfolio_thumb' );
				
				if( !$url_img ){
					$url_img = OVAPOR_PLUGIN_URI.'assets/img/placeholder.jpg';
				}
				$title = get_the_title( $id );
				$link = get_the_permalink( $id );

				$cat_por = get_cat_id_por_by_id_por( $id );

				$gallery = get_post_meta( $id, 'ova_por_met_gallery', true );

		?>
			<div class="ovapor-item <?php echo esc_attr( $cat_por ); ?>">
				<?php if( $url_img ){ ?>
					<a href="<?php echo esc_url( $link ); ?>" >
						<?php if( ! empty( $gallery ) ){ ?>
						<span class="number-gallery">
							<i data-feather="image"></i>
							<span>
								<?php echo count( $gallery ); ?>
							</span>
						</span>
						<?php } ?>
						<img src="<?php echo esc_url( $url_img ); ?>" alt="<?php echo $title; ?>">
					</a>
					<div class="content-item">
						<div class="category">
							<?php get_category_por_by_id_por( $id ) ?>
						</div>
						<h2 class="title">
							<a class="second_font" href="<?php echo $link; ?>">
								<?php echo $title; ?>
							</a>
						</h2>
						<div class="readmore">
							<a href="<?php echo $link; ?>" title="<?php echo $title; ?>">
								<i data-feather="arrow-right"></i>
							</a>
						</div>
					</div>
				
				<?php } ?>
			</div>

		<?php } } wp_reset_postdata(); ?>
	</div>
</div>

<?php 
