<?php 
defined( 'ABSPATH' ) || exit();

if( !class_exists( 'OVADOC_assets' ) ){
	class OVADOC_assets{

		public function __construct(){

			add_action( 'wp_enqueue_scripts', array( $this, 'ovadoc_enqueue_scripts' ), 10, 0 );

			/* Add JS for Elementor */
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'ova_enqueue_scripts_elementor_doc' ) );
		}

		public function ovadoc_enqueue_scripts(){

			// Init Css
			wp_enqueue_style( 'ovadoc_style', OVADOC_PLUGIN_URI.'assets/css/frontend/ovadoc-style.css' );		

		}

		// Add JS for elementor
		public function ova_enqueue_scripts_elementor_doc(){
			wp_enqueue_script( 'script-elementor-doc', OVADOC_PLUGIN_URI. 'assets/js/script-elementor.js', [ 'jquery' ], false, true );
		}

	}
	new OVADOC_assets();
}
