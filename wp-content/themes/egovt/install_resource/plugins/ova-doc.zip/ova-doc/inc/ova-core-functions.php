<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if( !function_exists( 'ovadoc_locate_template' ) ){
	function ovadoc_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovacoll-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ovadoc-templates/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVADOC_PLUGIN_PATH . 'templates/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			// $template_name
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovadoc_locate_template', $template, $template_name, $template_path, $default_path );
	}

}


function ovadoc_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;
	$template_file = ovadoc_locate_template( $template_name, $tempate_path, $default_path );
	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	
	include $template_file;
}


add_filter( 'egovt_header_customize', 'egovt_header_customize_doc', 10, 1 );
function egovt_header_customize_doc( $header ){


	if( is_tax( 'cat_doc' ) ||  get_query_var( 'cat_doc' ) != '' || is_post_type_archive( 'ova_doc' ) ){

	  	$header = get_theme_mod( 'header_archive_doc', 'default' );

	}else if( is_singular( 'ova_doc' ) ){

		$header = get_theme_mod( 'header_single_doc', 'default' );
	}

	return $header;

}


add_filter( 'egovt_header_bg_customize', 'egovt_header_bg_customize_doc', 10, 1 );
function egovt_header_bg_customize_doc( $bg ){

	if( is_tax( 'cat_doc' ) ||  get_query_var( 'cat_doc' ) != '' || is_post_type_archive( 'ova_doc' ) ){

	  	$bg = get_theme_mod( 'archive_background_doc', '' );

	}else if( is_singular( 'ova_doc' ) ){

		$bg = get_theme_mod( 'single_background_doc', '' );

		$current_id = egovt_get_current_id();
		$header_bg_source =  get_the_post_thumbnail_url( $current_id, 'full' );

		if( $header_bg_source ){
			$bg = $header_bg_source;
		}
		
	}


	return $bg;
}

add_filter( 'egovt_footer_customize', 'egovt_footer_customize_doc', 10, 1 );
function egovt_footer_customize_doc( $footer ){
    
   if( is_tax( 'cat_doc' ) ||  get_query_var( 'cat_doc' ) != '' || is_post_type_archive( 'ova_doc' ) ){

        $footer = get_theme_mod( 'archive_footer_doc', '' );

    }else if( is_singular( 'ova_doc' ) ){

        $footer = get_theme_mod( 'single_footer_doc', '' );
    }

    return $footer;

}