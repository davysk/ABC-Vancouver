<?php

if (!defined( 'ABSPATH' )) {
	exit;
}
if (!class_exists( 'Ova_Doc_Customize' )){

	class Ova_Doc_Customize {

		public function __construct() {
			add_action( 'customize_register', array( $this, 'ova_doc_customize_register' ) );
		}

		public function ova_doc_customize_register($wp_customize) {

			$this->ova_doc_init( $wp_customize );

			do_action( 'ova_doc_customize_register', $wp_customize );
		}


		/* Doc */
		public function ova_doc_init( $wp_customize ){

			$wp_customize->add_section( 'ova_doc_section' , array(
				'title'      => esc_html__( 'Document', 'ova-doc' ),
				'priority'   => 5,
			) );


			$wp_customize->add_setting( 'ova_doc_total_record', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '14',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_doc_total_record', array(
				'label' => esc_html__('Number of posts per page','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'ova_doc_total_record',
				'type' =>'number'
			));


			$wp_customize->add_setting( 'ova_doc_layout', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => 'two_column',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('ova_doc_layout', array(
				'label' => esc_html__('Layout','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'ova_doc_layout',
				'type' =>'select',
				'choices' => array(
					'one_column'      => __( '1 column', 'ova-doc' ),
					'two_column'      => __( '2 column', 'ova-doc' ),
					'three_column' => __( '3 column', 'ova-doc' ),
				)
			));


		    $wp_customize->add_setting( 'doc_image_sidebar', array(
		    	'type' => 'theme_mod', // or 'option'
			  	'capability' => 'edit_theme_options',
			  	'theme_supports' => '', // Rarely needed.
			  	'transport' => 'refresh', // or postMessage
			  	'sanitize_callback' => 'sanitize_text_field' // Get function name 
		    ));

		    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'doc_image_sidebar', array(
		        'label'    => __('Image Sidebar', 'ova-doc'),
		        'section'  => 'ova_doc_section',
		        'settings' => 'doc_image_sidebar'
		    )));


		    $wp_customize->add_setting( 'doc_link_image', array(
				  'type' => 'theme_mod', // or 'option'
				  'capability' => 'edit_theme_options',
				  'theme_supports' => '', // Rarely needed.
				  'default' => '#',
				  'transport' => 'refresh', // or postMessage
				  'sanitize_callback' => 'sanitize_text_field' // Get function name 
				  
				) );
			$wp_customize->add_control('doc_link_image', array(
				'label' => esc_html__('Link of image','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'doc_link_image',
				'type' =>'text',
				
			));



			$wp_customize->add_setting( 'archive_background_doc', array(
				'type' => 'theme_mod', // or 'option'
				'capability' => 'edit_theme_options',
				'theme_supports' => '', // Rarely needed.
				'transport' => 'refresh', // or postMessage
				'sanitize_callback' => 'sanitize_text_field' // Get function name 
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'archive_background_doc', array(
				'label'             => esc_html__('Background Archive Document', 'ova-doc'),
				'section'           => 'ova_doc_section',
				'settings'          => 'archive_background_doc',    
			)));

			$wp_customize->add_setting( 'single_background_doc', array(
				'type' => 'theme_mod', // or 'option'
				'capability' => 'edit_theme_options',
				'theme_supports' => '', // Rarely needed.
				'transport' => 'refresh', // or postMessage
				'sanitize_callback' => 'sanitize_text_field' // Get function name 
			) );
			$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'single_background_doc', array(
				'label'             => esc_html__('Background Single Document', 'ova-doc'),
				'section'           => 'ova_doc_section',
				'settings'          => 'single_background_doc',    
			)));
			

			$wp_customize->add_setting( 'header_archive_doc', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('header_archive_doc', array(
				'label' => esc_html__('Header Archive','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'header_archive_doc',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_header', '')
			));

			$wp_customize->add_setting( 'archive_footer_doc', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('archive_footer_doc', array(
				'label' => esc_html__('Footer Archive','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'archive_footer_doc',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_footer', '')
			));

			$wp_customize->add_setting( 'header_single_doc', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('header_single_doc', array(
				'label' => esc_html__('Header Single','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'header_single_doc',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_header', '')
			));

			$wp_customize->add_setting( 'single_footer_doc', array(
			  'type' => 'theme_mod', // or 'option'
			  'capability' => 'edit_theme_options',
			  'theme_supports' => '', // Rarely needed.
			  'default' => 'default',
			  'transport' => 'refresh', // or postMessage
			  'sanitize_callback' => 'sanitize_text_field' // Get function name 
			  
			) );
			$wp_customize->add_control('single_footer_doc', array(
				'label' => esc_html__('Footer Single','ova-doc'),
				'section' => 'ova_doc_section',
				'settings' => 'single_footer_doc',
				'type' =>'select',
				'choices' => apply_filters('egovt_list_footer', '')
			));

		}

	}

}

new Ova_Doc_Customize();






