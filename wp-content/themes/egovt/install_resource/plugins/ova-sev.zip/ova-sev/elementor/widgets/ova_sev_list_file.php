<?php
namespace ova_sev_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ova_sev_list_file extends Widget_Base {


	public function get_name() {
		return 'ova_sev_list_file';
	}

	public function get_title() {
		return __( 'Resource In Service', 'ova-sev' );
	}

	public function get_icon() {
		return 'far fa-file-alt';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'ova-sev' ),
			]
		);

		
		$this->add_control(
			'id_sev',
			[
				'label'   => __( 'Id Service', 'ova-sev' ),
				'type'    => Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'number_column',
			[
				'label' => __( 'Number Column', 'ova-sev' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'two_column',
				'options' => [
					'one_column' => __( '1 Column', 'ova-sev' ),
					'two_column'      => __( '2 Column', 'ova-sev' ),
				],
			]
		);


	}


	protected function render() {

		$settings = $this->get_settings();

		$template = apply_filters( 'el_elementor_ova_sev', 'elementor/ova_sev_list_file.php' );

		ob_start();
		ovasev_get_template( $template, $settings );
		echo ob_get_clean();
		
	}
}