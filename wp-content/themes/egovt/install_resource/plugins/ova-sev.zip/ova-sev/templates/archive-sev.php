<?php if ( !defined( 'ABSPATH' ) ) exit();

get_header();

$number_column = get_theme_mod( 'ova_sev_layout', 'three_column' );

?>

<div class="container">
	<div class="row">
		<div class="ova_sev_wrap archive_sev <?php echo esc_attr( $number_column ) ?>">
			<div class="content">
				<div class="wp-content">
				<?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<div class="items elementor-items">
						<div class="wp-items">
						<?php 
						$id = get_the_id();

						$class_icon = get_post_meta( $id, 'ova_sev_met_class_icon', true );
						$class_icon_hover = get_post_meta( $id, 'ova_sev_met_class_icon_hover', true );
						$title = get_the_title();
						$excerpt = get_the_excerpt();
						$link = get_the_permalink();
						?>

						<?php if( ! empty( $class_icon ) ) { ?>
							<div class="icon">
								<span class="<?php echo esc_attr( $class_icon ) ?>"></span>
							</div>
							<?php } ?>

							<?php if( ! empty( $title ) ){ ?>
								<h3 class="title">
									<a class="second_font" href="<?php echo esc_url( $link ) ?>">
										<?php echo $title ?>
									</a>
								</h3>
							<?php } ?>

							<div class="content-sub">
								<?php if( ! empty( $excerpt ) ){ ?>
								<p class="excerpt">
									<?php echo esc_html( $excerpt ) ?>
								</p>
								<?php } ?>
								
								
								<a href="<?php echo esc_url( $link ) ?>" class="second_font readmore">
									<?php echo esc_html__( 'Read More', 'ova-sev' ) ?>
									<i data-feather="arrow-right"></i>
								</a>
								
							</div>
							<?php if( ! empty( $class_icon_hover ) ) { ?>
							<div class="icon-hide">
								<span class="<?php echo esc_attr( $class_icon_hover ) ?>"></span>
							</div>
							<?php } ?>
							</div>
						</div>

				<?php endwhile; endif; wp_reset_postdata(); ?>
				</div>
			</div>
			
			<?php 
				egovt_pagination_theme();
			?>

		</div>
	</div>
</div>

<?php 
 get_footer();