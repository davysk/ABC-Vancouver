<?php
$category = $args['category'];
$number_column = $args['number_column'];


if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'ova_dep',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
	);
} else {
	$args_new= array(
		'post_type' => 'ova_dep',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_dep',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_dep_order = [];
if( $args['orderby_post'] === 'ova_dep_met_order_dep' ) {
	$args_dep_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_dep_order = [
		'orderby'        => $args['orderby_post'],
	];
}
$args_dep = array_merge( $args_new, $args_dep_order );

$deps  = new \WP_Query($args_dep);

?>


<div class="ova_list_dep <?php echo esc_attr( $number_column ) ?>">
	<div class="content">
		<?php if($deps->have_posts() ) : while ( $deps->have_posts() ) : $deps->the_post(); ?>

			<div class="items elementor-items">
				<?php 

				$id = get_the_id();

				$class_icon = get_post_meta( $id, 'ova_dep_met_class_icon', true );
				$title = get_the_title();
				$excerpt = get_the_excerpt();

				?>
				<?php if( ! empty( $class_icon ) ) { ?>
				<div class="icon-dep">
					<span class="<?php echo esc_attr( $class_icon ) ?>"></span>
				</div>
				<?php } ?>

				<?php if( ! empty( $title ) ){ ?>
					<h3 class="title-dep">
						<a href="<?php echo get_the_permalink() ?>">
							<?php echo $title ?>
						</a>
					</h3>
				<?php } ?>

				<div class="dep-content-sub">
					<?php if( ! empty( $excerpt ) ){ ?>
					<p class="dep-excerpt">
						<?php echo esc_html( $excerpt ) ?>
					</p>
					<?php } ?>
					<a href="<?php echo get_the_permalink() ?>" class="second_font dep-readmore">
						<?php echo esc_html__( 'Read More', 'ova-dep' ) ?>
						<i data-feather="arrow-right"></i>
					</a>
				</div>
				<?php if( ! empty( $class_icon ) ) { ?>
				<div class="icon-dep-hide">
					<span class="<?php echo esc_attr( $class_icon ) ?>"></span>
				</div>
				<?php } ?>

			</div>

		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>
</div>

