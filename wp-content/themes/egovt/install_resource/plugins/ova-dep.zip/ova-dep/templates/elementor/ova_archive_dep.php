<?php if ( !defined( 'ABSPATH' ) ) exit();

$category = $args['category'];
$number_column = $args['number_column'];

$show_icon = $args['show_icon'];
$show_title = $args['show_title'];
$show_excerpt = $args['show_excerpt'];
$show_readmore = $args['show_readmore'];


if( $category == 'all' ){
	$args_new= array(
		'post_type' => 'ova_dep',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
	);
} else {
	$args_new= array(
		'post_type' => 'ova_dep',
		'post_status' => 'publish',
		'posts_per_page' => $args['total_count'],
		'tax_query' => array(
			array(
				'taxonomy' => 'cat_dep',
				'field'    => 'slug',
				'terms'    => $category,
			)
		),
	);
}

$args_dep_order = [];
if( $args['orderby_post'] === 'ova_dep_met_order_dep' ) {
	$args_dep_order = [
		'meta_key'   => $args['orderby_post'],
		'orderby'    => 'meta_value_num',
		'meta_type' => 'NUMERIC',
		'order'   => "ASC",
	];
} else { 
	$args_dep_order = [
		'orderby'        => $args['orderby_post'],
	];
}
$args_dep = array_merge( $args_new, $args_dep_order );
$deps  = new \WP_Query($args_dep);

?>


<div class="ova_archive_dep archive_dep <?php echo esc_attr( $number_column ) ?>">
	<div class="content">
		<?php if( $deps->have_posts() ) : while ( $deps->have_posts() ) : $deps->the_post(); ?>

			<div class="items elementor-items">
				<div class="wp-item">
				<?php 

				$id = get_the_id();

				$class_icon = get_post_meta( $id, 'ova_dep_met_class_icon', true );
				$title = get_the_title();
				$excerpt = get_the_excerpt();
				$thumbnail = get_the_post_thumbnail( $id, 'large', array('class'=> 'img-responsive' ));
				?>

				<div class="ova-media">
					<a href="<?php echo get_the_permalink() ?>">
						<?php echo $thumbnail ?>
					</a>
				</div>
				<div class="ova-content">
					<?php if( $show_icon === 'yes' ){ ?>
						<div class="icon">
							<span>
								<i class="<?php echo esc_attr( $class_icon ) ?>"></i>
							</span>
						</div>
					<?php } ?>
					<?php if( $show_title === 'yes' ){ ?>
					<h2 class="title">
						<a class="second_font" href="<?php echo get_the_permalink() ?>">
							<?php echo $title ?>
						</a>
					</h2>
					<?php } ?>
					<?php if( ! empty( $excerpt ) && $show_excerpt === 'yes' ){ ?>
						<div class="descption">
							<?php echo $excerpt ?>
						</div>
					<?php } ?>
					<?php if( $show_readmore === 'yes' ){ ?>
					<a class="second_font readmore" href="<?php echo get_the_permalink() ?>" >
						<?php echo esc_html__( 'Read More', 'ova-dep' ) ?>
						<i data-feather="arrow-right"></i>
					</a>
					<?php } ?>
				</div>

				</div>
			</div>

		<?php endwhile; endif; wp_reset_postdata(); ?>
	</div>



</div>


<?php 
