<?php if ( !defined( 'ABSPATH' ) ) exit();
get_header( );
global $post;

$id = get_the_ID();

$list_document 			= get_post_meta( $id, 'ova_dep_met_list_file_dep', true );
$file_dep_sidebar 		= get_post_meta( $id, 'ova_dep_met_file_dep_sidebar', true );
$file_dep_sidebar_id 	= get_post_meta( $id, 'ova_dep_met_file_dep_sidebar_id', true );

$link_image = get_post_meta( $id, 'ova_dep_met_link_image', true );
$image 		= get_post_meta( $id, 'ova_dep_met_image', true );


$args = array(
	'post_type' => 'ova_dep',
	'posts_per_page' => -1,
);

$list_deps = get_posts( $args );

?>

<div class="container">
	<div class="row">
		<div class="ova_dep_wrap ova_dep_single">
			<div class="ova-dep-sidebar">
				<div class="ova_info">

					<div class="ova-list-dep">
						<a class="title-list-dep second_font" href="<?php echo get_post_type_archive_link('ova_dep') ?>">
							<i data-feather="chevron-left"></i>
							<?php echo esc_html__( 'All Departments', 'ova-dep' ) ?>
							
						</a>
						<ul>
						<?php
							if ($list_deps) {
								foreach ( $list_deps as $dep ) {
									$id_dep = $dep->ID;
									$title_dep = $dep->post_title;
									$class_active = ( $id == $id_dep ) ? 'active' : '';
									
									?>
									<li class="<?php echo esc_attr( $class_active ) ?>">
										<a class="second_font" href="<?php echo get_the_permalink( $id_dep ) ?>">
											<?php  echo esc_html( $title_dep ) ?>
										</a>
									</li>
									<?php
									// end if id!= id_dep
								}
							}
						?>
						</ul>
					</div>
					<!-- end ova-list-cat -->

					<?php if( ! empty( $file_dep_sidebar ) ){  
							$name_file = basename( $file_dep_sidebar );
							$ext_file = pathinfo( $name_file, PATHINFO_EXTENSION );

							if ( $file_dep_sidebar_id ) {
								// Get post from $file_id
								$files = ova_dep_get_name_files( $file_dep_sidebar_id );
								if ( !empty( $files ) ) {
									foreach ($files as $file) {
										$name_file = $file->post_title ? $file->post_title : $file->post_excerpt;
									}
								}
							}

							// Check empty $name_file
							if ( empty( $name_file ) ) {
								$name_file = basename( $file_dep_sidebar );
							}
						?>
							<div class="dep-file-sidebar">
								<span class="icon-attachment">
									<?php echo ova_doc_get_icon_attachment_file( $ext_file ) ?>
								</span>

								<span class="ova-file-name-size">
									<span class="ova-file-name">
										<a href="<?php echo $file_dep_sidebar ?>" download>
											<?php echo esc_html( $name_file ) ?>
										</a>
									</span>
									<span class="ova-file-size">
										<span class="type">
											<?php echo esc_html( $ext_file ) ?>
										</span>
										<span class="file-size">
											(<?php echo ova_doc_get_file_size( $file_dep_sidebar ) . esc_html__( 'kb', 'ova-doc' ) ?>)
										</span>
									</span>
								</span>
							</div>
					<?php } ?>

					<?php if( ! empty( $image ) ){ ?>
					<div class="ova-media">
						<a href="<?php echo esc_url( $link_image ) ?>">
							<img src="<?php echo esc_url( $image ) ?>" class="img-responsive" alt="<?php echo get_the_title() ?>">
						</a>
					</div>
					<?php } ?>
				</div>
			</div>
			<div class="ova_dep_content">

				<?php if( have_posts() ) : while( have_posts() ) : the_post();
					the_content();
		 		?>
		 		<?php endwhile; endif; wp_reset_postdata(); ?>


				<?php if( has_filter( 'ova_share_social' ) ){ ?>
			        <div class="share_social">
			        	<span class="ova_label second_font"><?php esc_html_e('Share Article ', 'ova-dep'); ?></span>
			        	<?php echo apply_filters('ova_share_social', get_the_permalink(), get_the_title() ); ?>
			        </div>
		        <?php } ?>

		        <?php
			        if( comments_open( get_the_ID() ) ) {
			        	comments_template(); 
			        }
		        ?>

			</div>
			<!-- end ova_dep_content -->
		</div>
		<!-- end ova_dep_single -->
	</div>
	<!-- end row -->
</div>
<!-- end container -->

<?php get_footer( );
