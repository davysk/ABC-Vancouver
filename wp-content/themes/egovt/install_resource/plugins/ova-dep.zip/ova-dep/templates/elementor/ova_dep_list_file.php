<?php

$id_dep = $args['id_dep'];
$id_dep = ! empty( $id_dep ) ? $id_dep : get_the_id();

$list_file_deps = get_post_meta( $id_dep, 'ova_dep_met_list_file_dep', true );
?>
<div class="ova_dep_list_file">
	<?php

	if( ! empty( $list_file_deps ) ){
		?>
		<ul class="ova-list-attachment">
			<?php
			foreach( $list_file_deps as $file_id => $file_dep ){

				$name_file 	= basename( $file_dep );
				$ext_file 	= pathinfo( $name_file, PATHINFO_EXTENSION );

				// Get post from $file_id
				$files = ova_dep_get_name_files( $file_id );
				if ( !empty( $files ) ) {
					foreach ($files as $file) {
						$name_file = $file->post_title ? $file->post_title : $file->post_excerpt;
					}
				}

				// Check empty $name_file
				if ( empty( $name_file ) ) {
					$name_file = basename( $file_dep );
				}

				?>
				<li>
					<span class="icon-attachment">
						<?php echo ova_doc_get_icon_attachment_file( $ext_file ) ?>
					</span>
					<span class="ova-file-name-size">
						<span class="ova-file-name">
							<?php echo esc_html( $name_file ) ?>
						</span>
						<span class="ova-file-size">
							<span class="type">
								<?php echo esc_html( $ext_file ) ?>
							</span>
							<span class="file-size">
								(<?php echo ova_doc_get_file_size( $file_dep ) . esc_html__( 'kb', 'ova-doc' ) ?>)
							</span>
						</span>
					</span>
					<span class="ova-download">
						<a href="<?php echo $file_dep ?>" download>
							<?php echo esc_html__( '[ download ]', 'ova-dep' ) ?>
						</a>
					</span>
				</li>

				<?php
			}

			?>
		</ul>
		<?php
	}

	?>
</div>

