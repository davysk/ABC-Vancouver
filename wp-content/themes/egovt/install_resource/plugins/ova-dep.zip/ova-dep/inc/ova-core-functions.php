<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if( !function_exists( 'ovadep_locate_template' ) ){
	function ovadep_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovacoll-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ovadep-templates/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVADEP_PLUGIN_PATH . 'templates/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			// $template_name
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovadep_locate_template', $template, $template_name, $template_path, $default_path );
	}

}


function ovadep_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;
	$template_file = ovadep_locate_template( $template_name, $tempate_path, $default_path );
	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	
	include $template_file;
}



add_filter( 'egovt_header_customize', 'egovt_header_customize_dep', 10, 1 );
function egovt_header_customize_dep( $header ){


	if( is_tax( 'cat_dep' ) ||  get_query_var( 'cat_dep' ) != '' || is_post_type_archive( 'ova_dep' ) ){

	  	$header = get_theme_mod( 'header_archive_dep', 'default' );

	}else if( is_singular( 'ova_dep' ) ){

		$header = get_theme_mod( 'header_single_dep', 'default' );
	}

	return $header;

}


add_filter( 'egovt_header_bg_customize', 'egovt_header_bg_customize_dep', 10, 1 );
function egovt_header_bg_customize_dep( $bg ){

	if( is_tax( 'cat_dep' ) ||  get_query_var( 'cat_dep' ) != '' || is_post_type_archive( 'ova_dep' ) ){

	  	$bg = get_theme_mod( 'archive_background_dep', '' );

	}else if( is_singular( 'ova_dep' ) ){

		$bg = get_theme_mod( 'single_background_dep', '' );

		$current_id = egovt_get_current_id();
		$header_bg_source =  get_the_post_thumbnail_url( $current_id, 'full' );

		if( $header_bg_source ){
			$bg = $header_bg_source;
		}
		
	}


	return $bg;
}


add_filter( 'egovt_footer_customize', 'egovt_footer_customize_dep', 10, 1 );
function egovt_footer_customize_dep( $footer ){
    
   if( is_tax( 'cat_dep' ) ||  get_query_var( 'cat_dep' ) != '' || is_post_type_archive( 'ova_dep' ) ){

        $footer = get_theme_mod( 'archive_footer_dep', '' );

    }else if( is_singular( 'ova_dep' ) ){

        $footer = get_theme_mod( 'single_footer_dep', '' );
    }

    return $footer;

}

