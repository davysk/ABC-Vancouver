<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'pre_get_posts', 'ova_dep_post_per_page_archive' );
function ova_dep_post_per_page_archive( $query ) {
	if ( ( is_post_type_archive( 'ova_dep' )  && !is_admin() )  || ( is_tax('cat_dep') && !is_admin() ) ) {
		if( $query->is_post_type_archive( 'ova_dep' ) || $query->is_tax('cat_dep') ) {
			$query->set('post_type', array( 'ova_dep' ) );
			$query->set('posts_per_page', get_theme_mod( 'ova_dep_total_record', 9 ) );
			$query->set('orderby', 'meta_value_num' );
	        $query->set('order', 'ASC' );
	        $query->set('meta_type', 'NUMERIC' );
	        $query->set('meta_key', 'ova_dep_met_order_dep' );
    	}
	}
}

function get_category_dep_by_id_dep( $id_dep = '' ){

	if( $id_dep === '' ) return;

	$cat_deps = get_the_terms( $id_dep, 'cat_dep' );
	$i = 0;

	if( ! empty( $cat_deps ) ){
		$count_cat = count( $cat_deps );
		?>
		<span class="separator-in dep-meta-general">
			<?php esc_html_e( '- In', 'ova-dep' ) ?>
		</span>
		<?php
		foreach ($cat_deps as $cat_dep) {
			$i++;
			$separator = ( $count_cat !== $i ) ? "," : "";

			$link = get_term_link($cat_dep->term_id);
			$name = $cat_dep->name;
			?>
				<span class="cat-dep">
					<a href="<?php echo esc_url( $link ) ?>"><?php echo esc_html( $name ) ?></a>
				</span>
				<span class="separator">
					<?php echo esc_html( $separator ) ?>
				</span>

			<?php
		}
	}
}

function ova_dep_get_icon_attachment_file( $ext_file = '' ){
	if( $ext_file == '' ) return '<i class="flaticon-file-2"></i>';

	if( $ext_file === 'docx' || $ext_file === 'doc' ){
		$icon = '<i class="flaticon-doc"></i>';
	} elseif( $ext_file === 'jpg' || $ext_file === 'gif' || $ext_file === 'png' ){
		$icon = '<i class="flaticon-file-5"></i>';
	} elseif( $ext_file === 'pdf' ){
		$icon = '<i class="flaticon-pdf"></i>';
	} else{
		$icon = '<i class="flaticon-file-2"></i>';
	}

	return $icon;
}

function ova_dep_get_file_size( $url_file = '' ){
	if( $url_file === '' ) return;
	$upload_dir = wp_upload_dir();
	$path_upload_full = $upload_dir['path'];

	$path_upload_sub = substr( $path_upload_full, 0, strpos( $path_upload_full, 'wp-content/uploads' ) );


	$position = strpos( $url_file, 'wp-content/uploads' );
	$sub_str = substr( $url_file, $position );
	$path_file = $path_upload_sub . $sub_str;

	$file_size_byte = filesize( $path_file );
	$file_size_kb = $file_size_byte * 0.0009765625;
	$file_size_kb = round( $file_size_kb );

	return $file_size_kb;
}

/**
 * Get files data from ID
 */
function ova_dep_get_name_files( $ID ) {
	$args = array(
	    'post_type' => 'attachment',
	    'p'		=> $ID
	);
	$query = new WP_Query( $args );

	return $query->posts;
}