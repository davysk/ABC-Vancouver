<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_feature_box extends Widget_Base {

	public function get_name() {
		return 'ova_feature_box';
	}

	public function get_title() {
		return __( 'Ova Box Feature', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'version',
			[
				'label' => __( 'Version', 'ova-framework' ),
				'type' 	=> Controls_Manager::SELECT,
				'default' => 'version_1',
				'options' => [
					'version_1' => esc_html__( 'Version 1', 'ova-framework' ),
					'version_2' => esc_html__( 'Version 2', 'ova-framework' ),
					'version_3' => esc_html__( 'Version 3', 'ova-framework' ),
				]
			]
		);
		

		$this->add_control(
			'image',
			[
				'label'   => 'Image ',
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'version' => 'version_1'
				],
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'lnr lnr-bus',
				'condition' => [
					'version!' => 'version_1',
				],
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Service Departments','ova-framework'),
			]
		);

		$this->add_control(
			'text_read_more',
			[
				'label' => __( 'Text Read More', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Learn More','ova-framework'),
				'condition' => [
					'version' => 'version_1'
				],
			]
		);
		$this->add_control(
			'sub_title',
			[
				'label' => __( 'Sub Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Doing the most good is hard. 
                 We recommend some of the best charities in the world.','ova-framework'),
				'condition' => [
					'version' => 'version_3'
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label' 	=> esc_html__( 'Link', 'ova-framework' ),
				'type' 		=> Controls_Manager::TEXT,
				'default' 	=> '#'
			]
		);

		$this->add_control(
			'target_link',
			[
				'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
				'type' 		=> Controls_Manager::SWITCHER,
				'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
				'label_off' => esc_html__( 'No', 'ova-framework' ),
				'default' 	=> 'no',
			]
		);

		$this->end_controls_section();
		

		// Style - General Section
		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'bg_color_hover',
				[
					'label' => __( 'Background Color Hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_feature_box.version_2:hover' => 'background : {{VALUE}};',
						'{{WRAPPER}} .ova_feature_box.version_3:hover' => 'background : {{VALUE}};',
					],
					'condition' => [
						'version!' => 'version_1',
					],
				]
			);

			$this->add_control(
				'circle_color',
				[
					'label' => __( 'Circle Color ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(255, 53, 20, 0.2)',
					'selectors' => [
						'{{WRAPPER}} .ova_feature_box.version_2 .ova-image a:after' => 'background : {{VALUE}};',
						'{{WRAPPER}} .ova_feature_box.version_3 .ova-image a:after' => 'background : {{VALUE}};',
					],
					'condition' => [
						'version!' => 'version_1',
					],
				]
			);

			$this->add_control(
				'circle_color_hover',
				[
					'label' => __( 'Circle Hover Color ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'default' => 'rgba(255, 53, 20, 0.2)',
					'selectors' => [
						'{{WRAPPER}} .ova_feature_box.version_2:hover .ova-image a:after' => 'background : {{VALUE}};',
						'{{WRAPPER}} .ova_feature_box.version_3:hover .ova-image a:after' => 'background : {{VALUE}};',
					],
					'condition' => [
						'version!' => 'version_1',	
					],
				]
			);
				$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color ', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_feature_box.version_2 .ova-image span:before' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_feature_box.version_3 .ova-image span:before' => 'color : {{VALUE}};',
					],
					'condition' => [
						'version!' => 'version_1',	
					],
				]
			);
			
			

		$this->end_controls_section(); // End - Style - General Section


		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_feature_box .ova-content .title a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box .ova-content .title a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_title_hover',
			[
				'label' => __( 'Color hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box .ova-content .title a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box .ova-content .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		

		

		$this->end_controls_section();

		$this->start_controls_section(
			'section_readmore',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version' => 'version_1'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'readmore_typography',
				'selector' => '{{WRAPPER}} .ova_feature_box .ova-content .readmore a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_readmore',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box .ova-content .readmore a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_readmore_hover',
			[
				'label' => __( 'Color hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box .ova-content .readmore a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_readmore',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box .ova-content .readmore a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		

		$this->end_controls_section();
			$this->start_controls_section(
			'section_sub_title',
			[
				'label' => __( 'Sub Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'version' => 'version_3'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'selector' => '{{WRAPPER}} .ova_feature_box.version_3 .ova-content .sub_title',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_sub_title',
			[
				'label' => __( 'Color Sub', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_feature_box.version_3 .ova-content .sub_title' => 'color : {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		
	}

	protected function render() {

		$settings 	= $this->get_settings();

		$version 	= $settings['version'];
		$class_icon = $settings['class_icon'];
		$title 		= $settings['title'];
		$subtitle 	= $settings['sub_title'];
		$read_more 	= $settings['text_read_more'];
		$link 		= $settings['link'];
		$target 	= '';
		if ( 'yes' == $settings['target_link'] ) {
			$target = ' target="_blank"';
		}

		$image_url 	= $settings['image']['url'];
		$image_id 	= $settings['image']['id'];
		$image_alt 	= "";

		if ( !empty( $image_id ) ) {
			$image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
			if ( empty( $image_alt ) ) {
				$image_alt = get_the_title( $image_id );
			}
		}
	
		?>
		<div class="ova_feature_box <?php echo esc_attr( $version ); ?>">
			<div class="ova-image">
				<a href="<?php echo esc_url( $link ); ?>" title="<?php echo esc_html( $title ); ?>"<?php echo esc_attr( $target ); ?>>
					<?php if( $version == 'version_1' ){ ?>
						<?php if ( $image_url ): ?>
							<img src="<?php echo esc_attr( $settings['image']['url'] ); ?>" alt="<?php echo $image_alt; ?>">
						<?php endif; ?>
					<?php } ?>
					<?php if( ($version == 'version_2' || $version == 'version_3')&& ! empty( $class_icon )){ ?>
						<span class="<?php echo esc_attr( $class_icon ); ?>"></span>
					<?php } ?>
				</a>
			</div>
			<div class="ova-content">
				<h3 class="title">
					<a href="<?php echo esc_url( $link ); ?>"<?php echo esc_attr( $target ); ?>>
						<?php echo esc_html( $title ); ?>
					</a>
				</h3>
				<?php if( $version == 'version_1' ){ ?>
				<div class="readmore">
					<a href="<?php echo esc_url( $link ); ?>" class="second_font"<?php echo esc_attr( $target ); ?>>
						<?php echo esc_html( $read_more ); ?>
						<i data-feather="chevron-right"></i>
					</a>
				</div>
				<?php } ?>
					<?php if( $version == 'version_3' ){ ?>
				<div class="sub_title">
						<?php echo esc_html( $subtitle ); ?>
				</div>
				<?php } ?>
			</div>

		</div>
		<?php
	}
}


