<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_contact_slide extends Widget_Base {

	public function get_name() {
		return 'ova_contact_slide';
	}

	public function get_title() {
		return __( 'Ova Contact Slide', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-sliders';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		// Carousel
		wp_enqueue_style( 'owl-carousel', OVA_PLUGIN_URI.'assets/libs/owl-carousel/assets/owl.carousel.min.css' );
		wp_enqueue_script( 'owl-carousel', OVA_PLUGIN_URI.'assets/libs/owl-carousel/owl.carousel.min.js', array('jquery'), false, true );
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$repeater = new \Elementor\Repeater();

				$repeater->add_control(
					'title',
					[
						'label'   => __( 'Title', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'address',
					[
						'label'   => __( 'Address', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXTAREA,
						'row'     => 2,
					]
				);

				$repeater->add_control(
					'text_email',
					[
						'label'   => __( 'Email Text', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'email',
					[
						'label'   => __( 'Email', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'text_phone',
					[
						'label'   => __( 'Phone Text', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'phone',
					[
						'label'   => __( 'Phone', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'text_read_more',
					[
						'label'   => __( 'Text Read More', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

				$repeater->add_control(
					'link',
					[
						'label'   => __( 'Link', 'ova-framework' ),
						'type'    => \Elementor\Controls_Manager::TEXT,
					]
				);

	

				$this->add_control(
					'tabs',
					[
						'label'       => 'Item',
						'type'        => Controls_Manager::REPEATER,
						'fields'      => $repeater->get_controls(),
						'default' => [
							[
								'title' => __('City Hall', 'ova-framework'),
								'address' => __('250 Main Street, Newton Hall,NY 52143', 'ova-framework'),
								'text_email' => __('president@example.com', 'ova-framework'),
								'email' => __('president@example.com', 'ova-framework'),
								'text_phone' => __('(+91) 800 235 9595', 'ova-framework'),
								'phone' => __('(+91)8002359595', 'ova-framework'),
								'text_read_more' => __('Get Direction', 'ova-framework'),
								'link' => '#',
							],

							[
								'title' => __('Police Department', 'ova-framework'),
								'address' => __('576 South Street, Police station, NY 13245', 'ova-framework'),
								'text_email' => __('Police@example.com', 'ova-framework'),
								'email' => __('police@example.com', 'ova-framework'),
								'text_phone' => __('Emergency: 911', 'ova-framework'),
								'phone' => __('911', 'ova-framework'),
								'text_read_more' => __('Get Direction', 'ova-framework'),
								'link' => '#',
							],
							[
								'title' => __('Medical Center', 'ova-framework'),
								'address' => __('65 Town hall Road, Benshall, Westhorn, NY 5623', 'ova-framework'),
								'text_email' => __('Health@example.com', 'ova-framework'),
								'email' => __('health@example.com', 'ova-framework'),
								'text_phone' => __('Emergency: 108', 'ova-framework'),
								'phone' => __('108', 'ova-framework'),
								'text_read_more' => __('Get Direction', 'ova-framework'),
								'link' => '#',
							],
						],
						'title_field' => '{{{ title }}}',
					]
				);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => __( 'Additional Options', 'ova-framework' ),
			]
		);


		/***************************  VERSION 1 ***********************/
			$this->add_control(
				'margin_items',
				[
					'label'   => __( 'Space between 2 items', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 30,
				]
				
			);

			$this->add_control(
				'item_number',
				[
					'label'       => __( 'Number of Items', 'ova-framework' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Number of Items', 'ova-framework' ),
					'default'     => 3,
				]
			);

	

			$this->add_control(
				'slides_to_scroll',
				[
					'label'       => __( 'Slides to Scroll', 'ova-framework' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => __( 'Set how many slides are scrolled per swipe.', 'ova-framework' ),
					'default'     => 1,
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label'   => __( 'Pause on Hover', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);


			$this->add_control(
				'infinite',
				[
					'label'   => __( 'Infinite Loop', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'   => __( 'Autoplay', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label'     => __( 'Autoplay Speed', 'ova-framework' ),
					'type'      => Controls_Manager::NUMBER,
					'default'   => 3000,
					'step'      => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => __( 'Smart Speed', 'ova-framework' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
				]
			);

			$this->add_control(
				'dot_control',
				[
					'label'   => __( 'Show Dots', 'ova-framework' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => __( 'Yes', 'ova-framework' ),
						'no'  => __( 'No', 'ova-framework' ),
					],
					'frontend_available' => true,
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .ova_contact_slide .slide-contact .item h3 a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item h3 a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bg_color_title',
			[
				'label' => __( 'Background Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item h3' => 'background-color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_title',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_address',
			[
				'label' => __( 'Address', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'address_typography',
				'selector' => '{{WRAPPER}} .ova_contact_slide .slide-contact .item .address p',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_address',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .address p' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_address',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .address p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_email',
			[
				'label' => __( 'Email', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'email_typography',
				'selector' => '{{WRAPPER}} .ova_contact_slide .slide-contact .item .mail a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_email',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .mail a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_email_hover',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .mail a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_email',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .mail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_phone',
			[
				'label' => __( 'Phone', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'phone_typography',
				'selector' => '{{WRAPPER}} .ova_contact_slide .slide-contact .item .phone a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_phone',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .phone a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_phone_hover',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .phone a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_phone',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .phone' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_text_read_more',
			[
				'label' => __( 'Text Read More', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'read_more_typography',
				'selector' => '{{WRAPPER}} .ova_contact_slide .slide-contact .item .read_more a',
				'scheme' => Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'color_read_more',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .read_more a' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_read_more_hover',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .read_more a:hover' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'margin_read_more',
			[
				'label' => __( 'Margin', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .read_more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'padding_read_more',
			[
				'label' => __( 'Padding', 'ova-framework' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .slide-contact .item .read_more a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_nav',
			[
				'label' => __( 'Nav', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'color_nav',
			[
				'label' => __( 'Color ', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .owl-carousel .owl-nav>button' => 'color : {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'color_nav_hover',
			[
				'label' => __( 'Color Hover', 'ova-framework' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .owl-carousel .owl-nav>button:hover i' => 'color : {{VALUE}};',
					'{{WRAPPER}} .ova_contact_slide .owl-carousel .owl-nav>button:hover ' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bottom_nav',
			[
				'label' => __( 'Bottom', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'max' => 200,
						'min' => -200,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .owl-carousel .owl-nav' => 'bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->add_control(
			'left_nav',
			[
				'label' => __( 'Left', 'ova-framework' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'max' => 200,
						'min' => -200,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ova_contact_slide .owl-carousel .owl-nav' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$tabs = $settings['tabs'];

		$data_options['items']              = $settings['item_number'];
		$data_options['slideBy']            = $settings['slides_to_scroll'];
		$data_options['margin']             = $settings['margin_items'];
		$data_options['autoplayHoverPause'] = $settings['pause_on_hover'] === 'yes' ? true : false;
		$data_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$data_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$data_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$data_options['smartSpeed']         = $settings['smartspeed'];
		$data_options['dots']               = $settings['dot_control'] === 'yes' ? true : false;
	
		?>
		<div class="ova_contact_slide ">
			
			<div class="slide-contact owl-carousel owl-theme " data-options="<?php echo esc_attr(json_encode($data_options)) ?>">
				
				<?php if( $tabs ){ ?>

					<?php foreach( $tabs as $tab ){ ?>
						<div class="item">
							<h3>
								<a href="<?php echo esc_url( $tab['link'] ) ?>">
									<?php echo esc_html( $tab['title'] ) ?>
								</a>
							</h3>
							<div class="address">
								<p>
									<?php echo  $tab['address'] ?>
								</p>
							</div>
							
							<div class="mail">
								
								<a href="mailto:<?php echo esc_attr( $tab['email'] ) ?>" class="email">
									<i class="far fa-envelope"></i>
									<?php echo esc_html( $tab['text_email'] ) ?>
								</a>
							</div>

							<div class="phone">

								<a href="tel:<?php echo esc_attr( $tab['phone'] ) ?>">
									<i class="fas fa-phone-alt"></i>
									<?php echo esc_html( $tab['text_phone'] ) ?>
								</a>
							</div>

							<div class="read_more">
								<a class="second_font" href="<?php echo esc_url( $tab['link'] ) ?>">
									<?php echo esc_html( $tab['text_read_more'] ) ?>
								</a>
							</div>

						</div>
					<?php } ?>

				<?php } ?>
			</div>
		</div>
		<?php
	}
}


