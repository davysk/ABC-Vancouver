<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_feature_3 extends Widget_Base {

	public function get_name() {
		return 'ova_box_feature_3';
	}

	public function get_title() {
		return __( 'Box Feature 3', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'flaticon-briefcase',
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Business','ova-framework'),
			]
		);


		$this->add_control(
			'excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'This present moment is perfect simply due to the fact you’re experiencing it. you can get away.','ova-framework' ),
			]
		);


		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => '#',
			]
		);

		$this->add_control(
			'target_link',
			[
				'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
				'type' 		=> Controls_Manager::SWITCHER,
				'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
				'label_off' => esc_html__( 'No', 'ova-framework' ),
				'default' 	=> 'no',
			]
		);

		$this->end_controls_section();


		// Style - Icon
		$this->start_controls_section(
			'icon_style',
			[
				'label' => __( 'Icon Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);	

			$this->add_control(
				'font_size_icon',
				[
					'label' => __( 'Icon Font Size', 'ova-framework' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px'],
					'range' => [
						'px' => [
							'max' => 1000,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 .icon i::before' => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .ova_box_feature_3 .icon i' => 'line-height: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'margin_icon',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 .icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);


			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 .icon i' => 'color : {{VALUE}};',
					],
					
				]
			);

			$this->add_control(
				'icon_color_hover',
				[
					'label' => __( 'Icon Color hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3:hover .icon i' => 'color : {{VALUE}};',
					],
					
				]
			);

		$this->end_controls_section(); // End Style - Icon


		// Style - Title
		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .ova_box_feature_3 h3.title a, {{WRAPPER}} .ova_box_feature_3 h3.title',
					'scheme' => Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_responsive_control(
				'margin_title',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 h3.title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 h3.title' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature_3 h3.title a' => 'color : {{VALUE}};',
					],
					
				]
			);

			

			$this->add_control(
				'title_color_hover',
				[
					'label' => __( 'Title Color hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3:hover h3.title' => 'color : {{VALUE}};',
						'{{WRAPPER}} .ova_box_feature_3:hover h3.title a' => 'color : {{VALUE}};',
					],
					
				]
			);


		$this->end_controls_section(); // End Style - Title


		// Style - Description
		$this->start_controls_section(
			'desc_style',
			[
				'label' => __( 'Description Style', 'ova-framework' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'desc_typography',
					'selector' => '{{WRAPPER}} .ova_box_feature_3 p.excerpt',
					'scheme' => Typography::TYPOGRAPHY_1,
				]
			);

			$this->add_responsive_control(
				'margin_desc',
				[
					'label' => __( 'Margin', 'ova-framework' ),
					'type' => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 p.excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'desc_color',
				[
					'label' => __( 'Description Color', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3 p.excerpt' => 'color : {{VALUE}};',
					],
					
				]
			);
			
			$this->add_control(
				'desc_color_hover',
				[
					'label' => __( 'Description Color hover', 'ova-framework' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_box_feature_3:hover p.excerpt' => 'color : {{VALUE}};',
					],
					
				]
			);

		$this->end_controls_section(); // End Style - Description
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$class_icon = $settings['class_icon'];
		$title = $settings['title'];
		$excerpt = $settings['excerpt'];
		$link = $settings['link'];
		if ( 'yes' == $settings['target_link'] ) {
			$target = ' target="_blank"';
		}
		$class_icon = $settings['class_icon'];
	
		?>
		<div class="ova_box_feature_3">

			

				<div class="left">

					<?php if( $class_icon ){ ?>
						<div class="icon">
							<i class="<?php echo esc_attr( $class_icon ); ?>"></i>
						</div>
					<?php } ?>

				</div>
				
				<div class="right">

					<?php if( $title ){ ?>
						<h3 class="title second_font ">
								<?php if( $link ){ ?>
									<a href="<?php echo esc_attr( $link ); ?>"<?php echo esc_html( $target ); ?>>
								<?php } ?>
									<?php echo $title; ?>
								<?php if( $link ){ ?>
									</a>
								<?php } ?>
						</h3>
					<?php } ?>

					<?php if( $excerpt ){ ?>
						<p class="excerpt">
							<?php echo $excerpt; ?>
						</p>
					<?php } ?>

				</div>	
				



		</div>

		<?php
		// end if version
	}
}


