<?php
namespace ova_framework\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Schemes\Color;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class ova_search_all extends Widget_Base {

	public function get_name() {
		return 'ova_search_all';
	}

	public function get_title() {
		return __( 'Search All', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-search';
	}

	public function get_categories() {
		return [ 'hf' ];
	}

	public function get_keywords() {
		return [ 'search_all' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_search',
			[
				'label' => __( 'Search All', 'ova-framework' ),
			]
		);
			
			$this->add_responsive_control(
				'type',
				[
					'label' => __( 'Type', 'elementor' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'type1',
					'options' => [
						'type1' => esc_html__( 'Type 1', 'ova-framework' ),
						'type2' => esc_html__( 'Type 2', 'ova-framework' ),
						'type3' => esc_html__( 'Type 3', 'ova-framework' ),
					],
				]
			);

			$this->add_control(
				'button_bg_color',
				[
					'label' => __( 'Button Background Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_wrap_search_all button' => 'background-color: {{VALUE}}',
						
					],
				]
			);

			$this->add_control(
				'border_button_color',
				[
					'label' => __( 'Border Button Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_wrap_search_all button' => 'border-color: {{VALUE}}',
						
					],
				]
			);



			$this->add_control(
				'button_bg_color_hover',
				[
					'label' => __( 'Button Background Color hover', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_wrap_search_all button:hover' => 'background-color: {{VALUE}}',

					],
				]
			);

			$this->add_control(
				'border_button_bg_color_hover',
				[
					'label' => __( 'Border Button Color hover', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_wrap_search_all button:hover' => 'border-color: {{VALUE}}',

					],
				]
			);

			$this->add_control(
				'button_color',
				[
					'label' => __( 'Button Color', 'ova-framework' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ova_wrap_search_all button' => 'color: {{VALUE}}',
					],
				]
			);

			
			

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings();

		$type = $settings['type'];

		if( $type == 'type1' ){
		?>
			<div class="ova_wrap_search_all type1">

				<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">

					<div class="wrap_field">
						<i class="flaticon-loupe"></i>
						<input type="text" class="search-field" placeholder="<?php esc_attr_e( 'How may we help you?', 'ova-framework' ); ?>" value="<?php echo get_search_query() ?>" aria-label="<?php esc_attr_e( 'How may we help you?', 'ova-framework' ); ?>" name="s" />
					</div>

				    <button class="search-submit second_font" type="submit" title="<?php echo esc_attr_x( 'Search', 'ova-framework' ); ?>"><?php echo esc_attr_x( 'Search', 'ova-framework' ); ?></button>
		   			 	
				</form>									
			</div>

		<?php }else if( $type == 'type2' ){ ?>
			<div class="ova_wrap_search_all type2">

				<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">

					<input type="text" class="search-field" placeholder="<?php esc_attr_e( 'Search Here...', 'ova-framework' ) ?>" value="<?php echo get_search_query(); ?>" aria-label="<?php esc_attr_e( 'Search Here...', 'ova-framework' ) ?>" name="s" />

				    <button class="search-submit" type="submit" title="<?php esc_attr_e( 'Search', 'ova-framework' ); ?>"><i class="icon_search"></i></button>
		   			 	
				</form>									
			</div>

		<?php }else if( $type == 'type3' ){ ?>
			<div class="ova_wrap_search_all type3">

				<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">

					<input type="text" class="search-field" placeholder="<?php esc_attr_e( 'Search Here...', 'ova-framework' ); ?>" value="<?php echo get_search_query(); ?>" aria-label="<?php esc_attr_e( 'Search Here...', 'ova-framework' ); ?>" name="s" />

				    <button class="search-submit" type="submit" title="<?php esc_attr_e( 'Search', 'ova-framework' ); ?>"><i class="icon_search"></i></button>
		   			 	
				</form>									
			</div>
		<?php } 
	}

}

