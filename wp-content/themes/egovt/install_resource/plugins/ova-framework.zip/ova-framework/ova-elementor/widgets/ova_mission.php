<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_mission extends Widget_Base {

	public function get_name() {
		return 'ova_mission';
	}

	public function get_title() {
		return __( 'Mission', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => 'Image',
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
				

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Balancing the Budget','ova-framework'),
			]
		);


		$this->add_control(
			'excerpt',
			[
				'label' => __( 'Excerpt', 'ova-framework' ),
				'type' => Controls_Manager::TEXTAREA,
				'row' => 2,
				'default' => __( 'City employment issue solved opportunities are osition level descriptions are listed.','ova-framework' ),
			]
		);

		$this->add_control(
			'read_more',
			[
				'label' => __( 'Read More', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Read More','ova-framework'),
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'Link', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => '#',
			]
		);

		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$title = $settings['title'];
		$image = $settings['image'];
		$excerpt = $settings['excerpt'];
		$read_more = $settings['read_more'];
		$link = $settings['link'];	
	
		?>

		<div class="ova_mission">
			<div class="items">
				<?php if( $image['url'] ){ ?>
					<div class="ova-media">
						<a href="<?php echo esc_url( $link ) ?>">
							<img src="<?php echo esc_url( $image['url'] ) ?>" alt="<?php echo esc_attr( $title ) ?>">
						</a>
					</div>
				<?php } ?>
				
				<div class="content">
					<?php if( ! empty( $title ) ){ ?>
						<h3 class="title">
							<a class="second_font" href="<?php echo esc_url( $link ) ?>">
								<?php echo $title ?>
							</a>
						</h3>
					<?php } ?>
					<?php if( ! empty( $excerpt ) ){ ?>
					<p class="excerpt">
						<?php echo esc_html( $excerpt ) ?>
					</p>
					<?php } ?>
					
					<?php if( ! empty( $read_more ) ){ ?>
					<a href="<?php echo esc_url( $link ) ?>" class="second_font readmore">
						<?php echo esc_html( $read_more ) ?>
						<i data-feather="arrow-right"></i>
					</a>
					<?php } ?>
				</div>

			</div>
		</div>
		

		<?php

	}
}


