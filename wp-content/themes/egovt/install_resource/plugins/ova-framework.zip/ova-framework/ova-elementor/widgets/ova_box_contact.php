<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_contact extends Widget_Base {

	public function get_name() {
		return 'ova_box_contact';
	}

	public function get_title() {
		return __( 'Box Contact', 'ova-framework' );
	}

	public function get_icon() {
		return 'fa fa-map-marker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
				
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Do you have request?Call or visit us.', 'ova-framework'),
			]
		);

		$this->add_control(
			'text_phone',
			[
				'label' => __( 'Text Phone', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Call: (807) 3500-7400', 'ova-framework'),
			]
		);

		$this->add_control(
			'phone',
			[
				'label' => __( 'Text Phone', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('(807)3500-7400', 'ova-framework'),
			]
		);

		$this->add_control(
			'title_address',
			[
				'label' => __( 'Title Address', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('City Council:', 'ova-framework'),
			]
		);

		$this->add_control(
			'address',
			[
				'label' => __( 'Address', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('95 FF3, App Street Avenue NSW 96209, Canada', 'ova-framework'),
			]
		);

		$this->add_control(
			'title_time',
			[
				'label' => __( 'Title Time', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Opening Hours:', 'ova-framework'),
			]
		);

		$this->add_control(
			'time',
			[
				'label' => __( 'Time open', 'ova-framework' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __('Mon – Fri: 8:00 am – 6:00 pm', 'ova-framework'),
			]
		);


		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$title = $settings['title'];
		$text_phone = $settings['text_phone'];
		$phone = $settings['phone'];

		$title_address = $settings['title_address'];
		$address = $settings['address'];

		$title_time = $settings['title_time'];
		$time = $settings['time'];

		
		?>
		<div class="ova_box_contact ">
			<?php if( $title ) { ?>
				<h3 class="title">
					<?php echo $title ?>
				</h3>
			<?php } ?>

			<?php if( $text_phone ) { ?>
				<div class="phone">
					<a href="tel:<?php echo esc_attr( $phone ) ?>" class="second_font">
						<?php echo $text_phone ?>
					</a>
				</div>
			<?php } ?>
			<div class="wrap-address">
				<p class="title-address title-general">
					<?php echo $title_address ?>
				</p>
				<p class="address content-general">
					<?php echo $address ?>
				</p>
			</div>

			<div class="wrap-time">
				<p class="title-time title-general">
					<?php echo $title_time ?>
				</p>
				<p class="time content-general">
					<?php echo $time ?>
				</p>
			</div>

		</div>
		<?php

	}
// end render
}


