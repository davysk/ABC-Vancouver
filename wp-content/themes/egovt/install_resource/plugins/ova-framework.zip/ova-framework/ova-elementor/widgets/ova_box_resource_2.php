<?php

namespace ova_framework\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Color;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ova_box_resource_2 extends Widget_Base {

	public function get_name() {
		return 'ova_box_resource_2';
	}

	public function get_title() {
		return __( 'Resource 2', 'ova-framework' );
	}

	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		return [ 'script-elementor' ];
	}

	protected function _register_controls() {


		$this->start_controls_section(
			'section_heading_content',
			[
				'label' => __( 'Content', 'ova-framework' ),
			]
		);

		$this->add_control(
			'class_icon',
			[
				'label' => __( 'Class Icon', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'flaticon-bank',
			]
		);


		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'ova-framework' ),
				'type' => Controls_Manager::TEXT,
				'default' => __('Your Goverment', 'ova-framework'),
			]
		);


		$repeater = new \Elementor\Repeater();

			$repeater->add_control(
				'label_link',
				[
					'label'   => esc_html__( 'Label', 'ova-framework' ),
					'type'    => \Elementor\Controls_Manager::TEXT,
				]
			);

			$repeater->add_control(
				'link',
				[
					'label' 	=> esc_html__( 'Link', 'ova-framework' ),
					'type' 		=> Controls_Manager::TEXT,
					'default' 	=> '#',
				]
			);

			$repeater->add_control(
				'target_link',
				[
					'label' 	=> esc_html__( 'Open in new window', 'ova-framework' ),
					'type' 		=> Controls_Manager::SWITCHER,
					'label_on' 	=> esc_html__( 'Yes', 'ova-framework' ),
					'label_off' => esc_html__( 'No', 'ova-framework' ),
					'default' 	=> 'no',
				]
			);

			$this->add_control(
				'tab_item',
				[
					'label'       => esc_html__( 'Item', 'ova-framework' ),
					'type'        => Controls_Manager::REPEATER,
					'fields'      => $repeater->get_controls(),
					'default' => [
						[
							'label_link' => __('City Councils', 'ova-framework'),
							'link' => '#',
							'target_link' => 'no',
						],
						[
							'label_link' => __('Services & Resources', 'ova-framework'),
							'link' => '#',
							'target_link' => 'no',
						],
						[
							'label_link' => __('Business & Residents', 'ova-framework'),
							'link' => '#',
							'target_link' => 'no',
						],
						[
							'label_link' => __('Goverment Departments', 'ova-framework'),
							'link' => '#',
							'target_link' => 'no',
						],
						[
							'label_link' => __('Town Gallery', 'ova-framework'),
							'link' => '#',
							'target_link' => 'no',
						],
						
					],
					'title_field' => '{{{ label_link }}}',
				]
			);


		$this->end_controls_section();
		
	}

	protected function render() {
		$settings = $this->get_settings();

		$class_icon = $settings['class_icon'];
		$title = $settings['title'];

		$tab_item = $settings['tab_item'];
	
		?>
		<div class="ova_box_resource_2">
				<?php if( $class_icon ){ ?>
				<div class="icon">
					<i class="<?php echo esc_attr( $class_icon ) ?>"></i>
				</div>
				<?php } ?>

				<?php if( $title ){ ?>
				<h3 class="title">
					<?php echo $title ?>
				</h3>
				<?php } ?>

				<?php if( ! empty( $tab_item ) ){ ?>
					<ul class="list-link">
						<?php foreach( $tab_item as $item ){ 
							$target 	= '';
							if ( 'yes' == $item['target_link'] ) {
								$target = ' target="_blank"';
							}
						?>
							<li>
								<a class="second_font" href="<?php echo esc_url( $item['link'] ) ?>"<?php echo esc_attr( $target ); ?>><?php echo esc_html( $item['label_link'] ) ?></a>
							</li> 
						<?php } ?>
					</ul>
					
				<?php } ?>

		</div>

		<?php
		// end if version
	}
}


