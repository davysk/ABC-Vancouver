<?php if ( !defined( 'ABSPATH' ) ) exit();

if( isset( $args['id'] ) ){
	$id = $args['id'];
}else{
	$id = get_the_id();	
}



$time_format = OVAEV_Settings::archive_event_format_time();

$ovaev_start_date 	= get_post_meta( $id, 'ovaev_start_date_time', true );
$ovaev_end_date   	= get_post_meta( $id, 'ovaev_end_date_time', true );

$ovaev_start_time 	= get_post_meta( $id, 'ovaev_start_time', true );
$ovaev_end_time 	= get_post_meta( $id, 'ovaev_end_time', true );

$date_start    = $ovaev_start_date != '' ? date_i18n(get_option('date_format'), $ovaev_start_date) : '';
$date_end      = $ovaev_end_date != '' ? date_i18n(get_option('date_format'), $ovaev_end_date) : '';

$time_start    = $ovaev_start_date != '' ? date_i18n( $time_format, $ovaev_start_date ) : '';
$time_end      = $ovaev_end_date != '' ? date_i18n( $time_format, $ovaev_end_date ) : '';

if( $date_start == $date_end && $date_start != '' && $date_end != '' ){ ?>
									
	<div class="time equal-date">
		<span class="icon-time">
			<i data-feather="clock"></i>
			<!-- <i class="far fa-clock icon_event"></i> -->
		</span>
		<span class="time-date-child">
			<?php if ( $ovaev_start_time && $ovaev_end_time ): ?>
				<span class="date-child">
					<?php echo esc_html($date_start) .' '. esc_html__( '@', 'ovaev' ); ?>
				</span>

				<span> <?php echo esc_html($time_start); ?> - </span>
				<span><?php echo esc_html($time_end); ?></span>
			<?php elseif ( $ovaev_start_time && $ovaev_end_time == '' ): ?>
				<span class="date-child">
					<?php echo esc_html($date_start) .' '. esc_html__( '@', 'ovaev' ); ?>
				</span>

				<span> <?php echo esc_html($time_start); ?></span>
			<?php else: ?>
				<span class="date-child">
					<?php echo esc_html($date_start); ?>
				</span>
			<?php endif; ?>
		</span>
	</div>

<?php } elseif( $date_start != $date_end && $date_start != '' && $date_end != '' ){ ?>
	
	<div class="time other-date">
		<span class="icon-time">
			<i data-feather="clock"></i>
			<!-- <i class="far fa-clock icon_event"></i> -->
		</span>
		<span class="time-date-child">
			<?php if ( $ovaev_start_time ): ?>
				<span><?php echo esc_html($date_start) . ' ' . esc_html($time_start);?> - </span>
			<?php else: ?>
				<span><?php echo esc_html($date_start);?> - </span>
			<?php endif; ?>
			<?php if ( $ovaev_end_time ): ?>
				<span><?php echo esc_html($date_end) . ' ' . esc_html($time_end);?></span>
			<?php else: ?>
				<span><?php echo esc_html($date_end);?></span>
			<?php endif; ?>
		</span>
	</div>

<?php } ?>