<?php if ( !defined( 'ABSPATH' ) ) exit();
get_header( );
global $post;

$id = get_the_ID();

$avatar = get_post_meta( $id, 'ova_team_met_avatar', true );
$job = get_post_meta( $id, 'ova_team_met_job', true );
$email = get_post_meta( $id, 'ova_team_met_email', true );
$phone = get_post_meta( $id, 'ova_team_met_phone', true );
$list_social = get_post_meta( $id, 'ova_team_met_group_icon', true );

$signature = get_post_meta( $id, 'ova_team_met_signature', true );

$expertise = get_post_meta( $id, 'ova_team_met_expertise', true );
$experience = get_post_meta( $id, 'ova_team_met_experience', true );

$signature = get_post_meta( $id, 'ova_team_met_signature', true );
$excerpt_1 = get_post_meta( $id, 'ova_team_met_excerpt_1', true );
$excerpt_2 = get_post_meta( $id, 'ova_team_met_excerpt_2', true );
$class_icon_bg = get_post_meta( $id, 'ova_team_met_class_icon_bg', true );

?>

<div class="container">
	<div class="row">
		<div class="ova_team_single">
			<div class="ova_info">
				<div class="image-team">
					<?php if( ! empty( $avatar ) ){ ?>
						<img src="<?php echo esc_url( $avatar ) ?>" class="img-responsive" alt="">
					<?php } ?>
				</div>
				<div class="content_info">
					<div class="ova-info-content">

							<p class="name second_font">
								<?php echo get_the_title() ?>
							</p>

							<?php if( ! empty( $job ) ) { ?>
								<p class="job">
									<?php echo esc_html( $job ) ?>
								</p>
							<?php } ?>

							<?php if( ! empty( $expertise ) ) { ?>
								<div class="ova-expertise">
									<label>
										<?php echo esc_html__('Expertise:', 'ova-team') ?>
									</label>
									<span><?php echo esc_html( $expertise ) ?></span>
								</div>
							<?php } ?>

							<?php if( ! empty( $experience ) ) { ?>
								<div class="ova-experience">
									<label>
										<?php echo esc_html__('Experience:', 'ova-team') ?>
									</label>
									<span><?php echo esc_html( $experience ) ?></span>
								</div>
							<?php } ?>

							<?php if( ! empty( $email ) ) { ?>
								<div class="ova-email">
									<label>
										<?php echo esc_html__('Email:', 'ova-team') ?>
									</label>
									<a href="mailto:<?php echo esc_attr( $email ) ?>" ><?php echo esc_html( $email ) ?></a>
								</div>
							<?php } ?>
							<?php if( ! empty( $phone ) ) { ?>
								<div class="ova-phone">
									<label>
										<?php echo esc_html__('Phone:', 'ova-team') ?>
									</label>
									<a href="tel:<?php echo esc_attr( $phone ) ?>" ><?php echo esc_html( $phone ) ?></a>
								</div>
							<?php } ?>

							<div class="ova-social">
								<ul>
									<?php 
									if( ! empty( $list_social ) ) { 
										foreach( $list_social as $social ){

											$class_icon = isset( $social['ova_team_met_class_icon_social'] ) ? $social['ova_team_met_class_icon_social'] : '';
											$link_social = isset( $social['ova_team_met_link_social'] ) ? $social['ova_team_met_link_social'] : '';
											?>
											<li>
												<a href="<?php echo esc_url( $link_social ); ?>" title="<?php echo esc_url( $link_social ); ?>">
													<i class="<?php echo esc_attr( $class_icon ) ?>"></i>
												</a>
											</li>
											<?php
										}
									} 
									?>
									
								</ul>
							</div>
							
						</div>
						<div class="ova-excerpt-team">
							<?php if( ! empty( $excerpt_1 ) ){ ?>
								<div class="excerpt-1">
									<p>
										<?php echo esc_html( $excerpt_1 ) ?>
									</p>
								</div>
							<?php } ?>

							<?php if( ! empty( $excerpt_2 ) ){ ?>
								<div class="excerpt-2">
									<p>
										<?php echo esc_html( $excerpt_2 ) ?>
									</p>
								</div>
							<?php } ?>

							<?php if( ! empty( $signature ) ){ ?>
								<img src="<?php echo esc_url( $signature ) ?>" alt="">
							<?php } ?>
						</div>
				</div>
				<?php if( ! empty( $class_icon_bg ) ) { ?>
				<div class="icon_bg">
					<i class="<?php echo esc_attr( $class_icon_bg ) ?>"></i>
				</div>
				<?php } ?>
			</div>
			<div class="ova_team_content">

				<?php if( have_posts() ) : while( have_posts() ) : the_post();
					the_content();
		 		?>
		 		<?php endwhile; endif; wp_reset_postdata(); ?>
			</div>
		</div>
	</div>
</div>

<?php get_footer( );
