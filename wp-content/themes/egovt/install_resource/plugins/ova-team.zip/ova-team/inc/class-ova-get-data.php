<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'pre_get_posts', 'team_post_per_page_archive' );
function team_post_per_page_archive( $query ) {
	if ( ( is_post_type_archive( 'team' )  && !is_admin() )  || ( is_tax('cat_team') && !is_admin() ) ) {
		if( $query->is_post_type_archive( 'team' ) || $query->is_tax('cat_team') ) {
			$query->set('post_type', array( 'team' ) );
			$query->set('posts_per_page', get_theme_mod( 'ova_team_total_record', 8 ) );
			$query->set('orderby', 'meta_value_num' );
            $query->set('order', 'ASC' );
            $query->set('meta_type', 'NUMERIC' );
            $query->set('meta_key', 'ova_team_met_order_team' );
		}
	}
}

/* Request for booking */
function send_mail_element( $data ){	

	$subject = isset( $data['your_subject'] ) ? sanitize_text_field( $data['your_subject'] ) : esc_html__( 'Mail to our team', 'ova-team' );
	$your_name = isset( $data['your_name'] ) ? sanitize_text_field( $data['your_name'] ) : '' ;
	$your_email = isset( $data['your_email'] ) ? sanitize_text_field( $data['your_email'] ) : '' ;
	$your_comment = isset( $data['your_comment'] ) ? sanitize_text_field( $data['your_comment'] ) : '' ;

    $body = '';

    $body .= $your_name ? esc_html__( 'Name: ', 'ova-team' ).$your_name.'<br/>' : '';
    $body .= $your_email ? esc_html__( 'Email: ', 'ova-team' ).$your_email.'<br/>' : '';
    $body .= $your_comment ? esc_html__( 'Comment: ', 'ova-team' ).$your_comment.'<br/>' : '';

    $mail_to = array( get_option('admin_email'), $your_email );

    return ova_team_sendmail( $mail_to, $subject, $body );

}


function ova_team_wp_mail_from(){
    return get_option('admin_email');
}

function ova_team_wp_mail_from_name(){
    return esc_html__("Send Mail To Our Team", 'ova-team');
}

function ova_team_sendmail( $mail_to, $subject, $body ){

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";
    
    add_filter( 'wp_mail_from', 'ova_team_wp_mail_from' );
    add_filter( 'wp_mail_from_name', 'ova_team_wp_mail_from_name' );


    if( wp_mail($mail_to, $subject, $body, $headers ) ){
        $result = true;
    }else{
        $result = false;
    }

    remove_filter( 'wp_mail_from', 'ova_team_wp_mail_from');
    remove_filter( 'wp_mail_from_name', 'ova_team_wp_mail_from_name' );

    return $result;
}



function ova_egovt_pagination_plugin($query = null) {

	/** Stop execution if there's only 1 page */
	if($query != null){
		if( $query->max_num_pages <= 1 )
			return;	
	}else if( $wp_query->max_num_pages <= 1 )
	return;



	$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;


	

	if($query!=null){
		$max   = intval( $query->max_num_pages );
	}else{
		$max   = intval( $wp_query->max_num_pages );	
	}
	

	/** Add current page to the array */
	if ( $paged >= 1 )
		$links[] = $paged;

	/** Add the pages around the current page to the array */
	if ( $paged >= 3 ) {
		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}

	if ( ( $paged + 2 ) <= $max ) {
		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}


	echo wp_kses( __( '<div class="blog_pagination"><ul class="pagination">','ova-collection' ), true ) . "\n";
	
	/** Previous Post Link */
	if ( get_previous_posts_link() )
		printf( '<li class="prev page-numbers">%s</li>' . "\n", get_previous_posts_link('<i class="arrow_carrot-left"></i>') );
	
	/** Link to first page, plus ellipses if necessary */
	if ( ! in_array( 1, $links ) ) {
		$class = 1 == $paged ? ' class="active"' : '';
		
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );
		
		if ( ! in_array( 2, $links ) )
			echo wp_kses( __('<li><span class="pagi_dots">...</span></li>', 'ova-collection' ) , true);
	}
	
	/** Link to current page, plus 2 pages in either direction if necessary */
	sort( $links );
	foreach ( (array) $links as $link ) {
		$class = $paged == $link ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
	}
	
	/** Link to last page, plus ellipses if necessary */
	if ( ! in_array( $max, $links ) ) {
		if ( ! in_array( $max - 1, $links ) )
			echo wp_kses( __('<li><span class="pagi_dots">...</span></li>', 'ova-collection' ) , true) . "\n";
		
		$class = $paged == $max ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
	}
	
	/** Next Post Link */
	if ( get_next_posts_link() )
		printf( '<li class="next page-numbers">%s</li>' . "\n", get_next_posts_link('<i class="arrow_carrot-right"></i>') );
	
	echo wp_kses( __( '</ul></div>', 'ova-collection' ), true ) . "\n";

}